// Types matching the Supabase GTFS schema

export type EntityStatus = 'existing' | 'pending' | 'approved' | 'rejected';
export type UserRole = 'viewer' | 'editor' | 'reviewer';

export interface Stop {
  id: string;
  name: string | null;
  lat: number;
  lon: number;
  status: EntityStatus;
  contributor_id: string | null;
  created_at: string;
}

export interface Trip {
  id: string;
  name: string;
  status: EntityStatus;
  contributor_id: string | null;
  reviewer_id: string | null;
  review_note: string | null;
  reviewed_at: string | null;
  created_at: string;
  parent_trip_id: string | null;
}

export interface TripStop {
  id: string;
  trip_id: string;
  stop_id: string;
  stop_sequence: number;
}

export interface TripShape {
  id: string;
  trip_id: string;
  geojson: GeoJSON.LineString;
}

export interface Fare {
  id: string;
  trip_id: string;
  amount: number | null;
  currency: string;
}

export interface TripDuration {
  id: string;
  trip_id: string;
  duration_seconds: number | null;
}

export interface Profile {
  id: string;
  role: UserRole;
}

// Joins
export interface TripWithDetails extends Trip {
  trip_stops?: (TripStop & { stop?: Stop })[];
  trip_shapes?: TripShape;
  fares?: Fare;
  trip_durations?: TripDuration;
  profiles?: Profile;
}

// Database type map for Supabase client
export interface Database {
  public: {
    Tables: {
      stops: {
        Row: Stop;
        Insert: Omit<Stop, 'id' | 'created_at'> & { id?: string; created_at?: string };
        Update: Partial<Stop>;
      };
      trips: {
        Row: Trip;
        Insert: Omit<Trip, 'id' | 'created_at'> & { id?: string; created_at?: string };
        Update: Partial<Trip>;
      };
      trip_stops: {
        Row: TripStop;
        Insert: Omit<TripStop, 'id'> & { id?: string };
        Update: Partial<TripStop>;
      };
      trip_shapes: {
        Row: TripShape;
        Insert: Omit<TripShape, 'id'> & { id?: string };
        Update: Partial<TripShape>;
      };
      fares: {
        Row: Fare;
        Insert: Omit<Fare, 'id'> & { id?: string };
        Update: Partial<Fare>;
      };
      trip_durations: {
        Row: TripDuration;
        Insert: Omit<TripDuration, 'id'> & { id?: string };
        Update: Partial<TripDuration>;
      };
      profiles: {
        Row: Profile;
        Insert: Profile;
        Update: Partial<Profile>;
      };
    };
    Enums: {
      entity_status: EntityStatus;
    };
  };
}