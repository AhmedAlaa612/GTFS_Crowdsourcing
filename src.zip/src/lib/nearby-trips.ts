const NEARBY_TRIPS_API = process.env.NEXT_PUBLIC_NEARBY_TRIPS_API_URL || process.env.NEARBY_TRIPS_API_URL;

export interface NearbyTrip {
  id?: string;
  name: string;
  fare?: number | null;
  status?: string;
  distance_m?: number;
}

export interface NearbyTripsResponse {
  trips: NearbyTrip[];
}

export async function getNearbyTrips(
  lat: number,
  lon: number,
  radiusM = 1000,
  startsOnly = false
): Promise<NearbyTripsResponse> {
  if (!NEARBY_TRIPS_API) {
    console.warn('NEARBY_TRIPS_API_URL not configured');
    return { trips: [] };
  }

  try {
    const url = `${NEARBY_TRIPS_API}/nearby-trips?lat=${lat}&lon=${lon}&radius_m=${radiusM}&starts=${startsOnly}`;
    const res = await fetch(url, { next: { revalidate: 60 } });

    if (!res.ok) {
      console.error('Nearby trips API failed:', res.status);
      return { trips: [] };
    }

    return res.json();
  } catch (error) {
    console.error('Nearby trips API error:', error);
    return { trips: [] };
  }
}
