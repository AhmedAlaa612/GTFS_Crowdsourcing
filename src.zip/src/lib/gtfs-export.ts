import JSZip from 'jszip';
import type { Stop, Trip, TripStop, TripShape, Fare } from './database.types';

interface ExportData {
  trips: Trip[];
  stops: Stop[];
  tripStops: TripStop[];
  tripShapes: TripShape[];
  fares: Fare[];
}

export async function buildGtfsZip(data: ExportData): Promise<Buffer> {
  const zip = new JSZip();

  // agency.txt
  zip.file(
    'agency.txt',
    'agency_id,agency_name,agency_url,agency_timezone\n' +
    'crowd,Alexandria Transit (Crowd-sourced),https://crowd.example.com,Africa/Cairo\n'
  );

  // stops.txt
  const stopsHeader = 'stop_id,stop_name,stop_lat,stop_lon\n';
  const stopsRows = data.stops
    .map((s) => `${s.id},${csvEscape(s.name || 'Unnamed Stop')},${s.lat},${s.lon}`)
    .join('\n');
  zip.file('stops.txt', stopsHeader + stopsRows + '\n');

  // routes.txt
  const routesHeader = 'route_id,agency_id,route_short_name,route_long_name,route_type\n';
  const routesRows = data.trips
    .map((t) => `${t.id},crowd,${csvEscape(t.name)},${csvEscape(t.name)},3`)
    .join('\n');
  zip.file('routes.txt', routesHeader + routesRows + '\n');

  // trips.txt
  const tripsHeader = 'route_id,service_id,trip_id,trip_headsign,shape_id\n';
  const tripsRows = data.trips
    .map((t) => `${t.id},always,${t.id},${csvEscape(t.name)},shape_${t.id}`)
    .join('\n');
  zip.file('trips.txt', tripsHeader + tripsRows + '\n');

  // calendar.txt (always-running service)
  zip.file(
    'calendar.txt',
    'service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,start_date,end_date\n' +
    'always,1,1,1,1,1,1,1,20240101,20301231\n'
  );

  // stop_times.txt
  const stopTimesHeader = 'trip_id,arrival_time,departure_time,stop_id,stop_sequence\n';
  const stopTimesRows = data.tripStops
    .map((ts) => `${ts.trip_id},,, ${ts.stop_id},${ts.stop_sequence}`)
    .join('\n');
  zip.file('stop_times.txt', stopTimesHeader + stopTimesRows + '\n');

  // shapes.txt
  const shapesHeader = 'shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence\n';
  const shapesRows: string[] = [];
  for (const shape of data.tripShapes) {
    const geojson = shape.geojson as GeoJSON.LineString;
    if (geojson?.coordinates) {
      geojson.coordinates.forEach((coord, idx) => {
        shapesRows.push(`shape_${shape.trip_id},${coord[1]},${coord[0]},${idx}`);
      });
    }
  }
  zip.file('shapes.txt', shapesHeader + shapesRows.join('\n') + '\n');

  // fare_attributes.txt (if any fares exist)
  if (data.fares.length > 0) {
    const fareHeader = 'fare_id,price,currency_type,payment_method,transfers\n';
    const fareRows = data.fares
      .filter((f) => f.amount !== null)
      .map((f) => `fare_${f.trip_id},${f.amount},${f.currency || 'EGP'},0,0`)
      .join('\n');
    zip.file('fare_attributes.txt', fareHeader + fareRows + '\n');
  }

  const buffer = await zip.generateAsync({ type: 'nodebuffer' });
  return buffer;
}

function csvEscape(value: string): string {
  if (value.includes(',') || value.includes('"') || value.includes('\n')) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}
