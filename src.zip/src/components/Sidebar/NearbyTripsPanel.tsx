'use client';

import { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';
import type { NearbyTrip } from '@/lib/nearby-trips';

interface NearbyTripsPanelProps {
  lat: number;
  lon: number;
  isLoggedIn: boolean;
}

export function NearbyTripsPanel({ lat, lon, isLoggedIn }: NearbyTripsPanelProps) {
  const [trips, setTrips] = useState<NearbyTrip[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const fetchNearby = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(
          `/api/nearby?lat=${lat}&lon=${lon}&radius_m=1000`
        );
        if (!res.ok) throw new Error('Failed to fetch');
        const data = await res.json();
        setTrips(data.trips || []);
      } catch {
        setError('Could not load nearby trips');
        setTrips([]);
      } finally {
        setLoading(false);
      }
    };
    fetchNearby();
  }, [lat, lon]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold">Nearby Trips</h3>
        <p className="text-sm text-muted-foreground">
          Routes passing near this location
        </p>
      </div>

      {error && (
        <p className="text-sm text-muted-foreground bg-muted rounded-lg px-3 py-2">
          {error}. The nearby trips API may not be running.
        </p>
      )}

      {trips.length === 0 && !error && (
        <p className="text-sm text-muted-foreground">
          No trips found near this location.
        </p>
      )}

      <div className="space-y-2">
        {trips.map((trip, idx) => (
          <div
            key={trip.id || idx}
            className="p-3 rounded-lg border border-border/50 bg-card hover:bg-accent/50 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="font-medium text-sm">{trip.name}</span>
              {trip.status && (
                <Badge variant="secondary" className="text-xs">
                  {trip.status}
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {trip.fare != null ? `${trip.fare} EGP` : 'Fare unknown'}
            </p>
          </div>
        ))}
      </div>

      <div className="pt-2 border-t border-border/50">
        <p className="text-sm text-muted-foreground mb-2">
          Don&apos;t see your route?
        </p>
        <Button
          size="sm"
          className="w-full"
          onClick={() => {
            if (isLoggedIn) {
              router.push('/contribute');
            } else {
              router.push('/?toast=login_required');
            }
          }}
        >
          ✚ Add it
        </Button>
      </div>
    </div>
  );
}
