'use client';

import { useState, useMemo, useRef, useEffect } from 'react';
import type { Trip, Fare, TripDuration } from '@/lib/database.types';
import { formatDuration } from '@/lib/osrm';

interface RoutesPanelProps {
  trips: Trip[];
  fares: Fare[];
  durations: TripDuration[];
  selectedTripId: string | null;
  onSelectTrip: (trip: Trip) => void;
}

export function RoutesPanel({ trips, fares, durations, selectedTripId, onSelectTrip }: RoutesPanelProps) {
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const filtered = useMemo(() => {
    if (!search.trim()) return trips;
    const q = search.toLowerCase();
    return trips.filter((t) => t.name.toLowerCase().includes(q));
  }, [trips, search]);

  // Open panel when user starts typing
  useEffect(() => {
    if (search.trim()) setOpen(true);
  }, [search]);

  const handleSelect = (trip: Trip) => {
    onSelectTrip(trip);
    setOpen(false);
    setSearch('');
    inputRef.current?.blur();
  };

  return (
    <div
      style={{
        position: 'absolute',
        top: 12,
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 25,
        width: 'min(420px, calc(100vw - 32px))',
      }}
    >
      {/* Search bar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          background: 'hsl(var(--background) / 0.97)',
          border: '1px solid hsl(var(--border) / 0.6)',
          borderRadius: open ? '12px 12px 0 0' : 12,
          padding: '8px 14px',
          boxShadow: '0 4px 24px rgba(0,0,0,0.35)',
          backdropFilter: 'blur(12px)',
          transition: 'border-radius 0.15s',
        }}
      >
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" style={{ flexShrink: 0, opacity: 0.45 }}>
          <path d="M10 6.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-.691 3.516 2.838 2.837a.5.5 0 0 1-.707.707L8.602 9.723A4.5 4.5 0 1 1 9.309 9.016Z" fill="currentColor" fillRule="evenodd" clipRule="evenodd"/>
        </svg>
        <input
          ref={inputRef}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onFocus={() => setOpen(true)}
          placeholder={`Search ${trips.length} routes…`}
          style={{
            flex: 1,
            background: 'transparent',
            border: 'none',
            outline: 'none',
            fontSize: 14,
            color: 'hsl(var(--foreground))',
            fontFamily: 'inherit',
          }}
        />
        {search && (
          <button
            onClick={() => { setSearch(''); inputRef.current?.focus(); }}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              padding: 2, opacity: 0.5, color: 'hsl(var(--foreground))',
              fontSize: 16, lineHeight: 1,
            }}
          >✕</button>
        )}
        {!search && (
          <button
            onClick={() => setOpen((v) => !v)}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              padding: '2px 6px', opacity: 0.5, color: 'hsl(var(--foreground))',
              fontSize: 11, lineHeight: 1, letterSpacing: '0.05em',
              fontWeight: 600,
            }}
          >
            {open ? '▲' : '▼'}
          </button>
        )}
      </div>

      {/* Dropdown list */}
      {open && (
        <>
          {/* backdrop to close */}
          <div
            style={{ position: 'fixed', inset: 0, zIndex: -1 }}
            onClick={() => { setOpen(false); setSearch(''); }}
          />
          <div
            style={{
              background: 'hsl(var(--background) / 0.97)',
              border: '1px solid hsl(var(--border) / 0.6)',
              borderTop: 'none',
              borderRadius: '0 0 12px 12px',
              boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
              backdropFilter: 'blur(12px)',
              maxHeight: 360,
              overflowY: 'auto',
            }}
          >
            {filtered.length === 0 ? (
              <div style={{ padding: '20px 16px', textAlign: 'center', opacity: 0.5, fontSize: 13 }}>
                No routes match &quot;{search}&quot;
              </div>
            ) : (
              filtered.map((trip) => {
                const fare = fares.find((f) => f.trip_id === trip.id);
                const dur = durations.find((d) => d.trip_id === trip.id);
                const isSelected = trip.id === selectedTripId;

                return (
                  <button
                    key={trip.id}
                    onClick={() => handleSelect(trip)}
                    style={{
                      width: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      gap: 12,
                      padding: '10px 14px',
                      background: isSelected ? 'hsl(var(--primary) / 0.08)' : 'transparent',
                      border: 'none',
                      borderBottom: '1px solid hsl(var(--border) / 0.3)',
                      cursor: 'pointer',
                      textAlign: 'left',
                      transition: 'background 0.1s',
                    }}
                    onMouseEnter={(e) => {
                      if (!isSelected) (e.currentTarget as HTMLElement).style.background = 'hsl(var(--accent) / 0.5)';
                    }}
                    onMouseLeave={(e) => {
                      if (!isSelected) (e.currentTarget as HTMLElement).style.background = 'transparent';
                    }}
                  >
                    {/* Bus icon dot */}
                    <div style={{
                      width: 32, height: 32, borderRadius: 8, flexShrink: 0,
                      background: isSelected ? 'hsl(var(--primary))' : 'hsl(var(--muted))',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 15, transition: 'background 0.1s',
                    }}>
                      🚌
                    </div>

                    {/* Name + meta */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{
                        fontSize: 13, fontWeight: 600,
                        color: isSelected ? 'hsl(var(--primary))' : 'hsl(var(--foreground))',
                        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                      }}>
                        {trip.name}
                      </div>
                      <div style={{ fontSize: 11, opacity: 0.5, marginTop: 2, display: 'flex', gap: 8 }}>
                        {fare?.amount != null && (
                          <span>{fare.amount} {fare.currency || 'EGP'}</span>
                        )}
                        {dur?.duration_seconds != null && (
                          <span>{formatDuration(dur.duration_seconds)}</span>
                        )}
                      </div>
                    </div>

                    {isSelected && (
                      <div style={{ fontSize: 11, opacity: 0.6, flexShrink: 0, color: 'hsl(var(--primary))' }}>
                        ✓ on map
                      </div>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </>
      )}
    </div>
  );
}