'use client';

import { useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import type { Trip, Stop, Fare, TripDuration } from '@/lib/database.types';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { formatDuration, getRouteShape } from '@/lib/osrm';
import { createClient } from '@/lib/supabase';
import { toast } from 'sonner';
import dynamic from 'next/dynamic';

const MapView = dynamic(
  () => import('@/components/Map/MapView').then((mod) => mod.MapView),
  { ssr: false }
);
const EditMapLayer = dynamic(
  () => import('@/components/Review/EditMapLayer').then((mod) => mod.EditMapLayer),
  { ssr: false }
);

const supabase = createClient();

interface TripDetailProps {
  trip: Trip;
  stops: Stop[];
  fare?: Fare | null;
  duration?: TripDuration | null;
}

function StopEditor({
  open,
  onOpenChange,
  trip,
  initialStops,
  fare,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  trip: Trip;
  initialStops: Stop[];
  fare: Fare | null | undefined;
}) {
  const [editStops, setEditStops] = useState<Stop[]>([]);
  const [editFare, setEditFare] = useState('');
  const [allStops, setAllStops] = useState<Stop[]>([]);
  const [mapReady, setMapReady] = useState(false);
  const [saving, setSaving] = useState(false);
  const [highlightedIdx, setHighlightedIdx] = useState<number | null>(null);
  const [showSeqPrompt, setShowSeqPrompt] = useState(false);
  const [seqValue, setSeqValue] = useState('');
  const [pendingMapStop, setPendingMapStop] = useState<Stop | null>(null);
  const [pendingCoord, setPendingCoord] = useState<{ lat: number; lon: number } | null>(null);
  const listRefs = useRef<(HTMLDivElement | null)[]>([]);
  const didInit = useRef(false);

  if (open && !didInit.current) {
    didInit.current = true;
    setEditStops([...initialStops]);
    setEditFare(fare?.amount?.toString() ?? '');
    setHighlightedIdx(null);
    setMapReady(false);
    supabase.from('stops').select('*').then(({ data }) => setAllStops(data || []));
    setTimeout(() => setMapReady(true), 50);
  }
  if (!open && didInit.current) didInit.current = false;

  const handleMapStopClick = (stop: Stop) => {
    if (editStops.some((s) => s.id === stop.id)) { toast.info('Stop already in route'); return; }
    setPendingMapStop(stop); setPendingCoord(null);
    setSeqValue(String(editStops.length + 1)); setShowSeqPrompt(true);
  };

  const handleMapCoordClick = ({ lat, lng }: { lat: number; lng: number }) => {
    if (showSeqPrompt) return;
    setPendingCoord({ lat, lon: lng } as any); setPendingMapStop(null);
    setSeqValue(String(editStops.length + 1)); setShowSeqPrompt(true);
  };

  const handleSequenceConfirm = (seq: number) => {
    setShowSeqPrompt(false);
    const idx = seq - 1;
    if (pendingMapStop) {
      const next = [...editStops]; next.splice(idx, 0, pendingMapStop);
      setEditStops(next); setHighlightedIdx(idx);
    } else if (pendingCoord) {
      const newStop: Stop = { id: `new-${Date.now()}`, name: '', lat: pendingCoord.lat, lon: (pendingCoord as any).lon, status: 'pending', contributor_id: null, created_at: new Date().toISOString() };
      const next = [...editStops]; next.splice(idx, 0, newStop);
      setEditStops(next); setHighlightedIdx(idx);
    }
    setPendingMapStop(null); setPendingCoord(null);
  };

  const moveStop = (idx: number, dir: -1 | 1) => {
    const next = [...editStops]; const swap = idx + dir;
    if (swap < 0 || swap >= next.length) return;
    [next[idx], next[swap]] = [next[swap], next[idx]];
    setEditStops(next); setHighlightedIdx(swap);
  };

  const removeStop = (idx: number) => { setEditStops((prev) => prev.filter((_, i) => i !== idx)); setHighlightedIdx(null); };
  const updateStopName = (idx: number, name: string) => { setEditStops((prev) => prev.map((s, i) => i === idx ? { ...s, name } : s)); };

  const handleSubmitForReview = async () => {
    if (editStops.length < 2) { toast.error('Need at least 2 stops'); return; }
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { toast.error('Please log in to submit'); setSaving(false); return; }

      const { data: newTrip, error: tripErr } = await supabase
        .from('trips').insert({ name: trip.name, status: 'pending', contributor_id: user.id, parent_trip_id: trip.id } as any)
        .select().single();
      if (tripErr || !newTrip) throw tripErr || new Error('Failed to create trip');

      const resolvedStops: Stop[] = [];
      for (const stop of editStops) {
        if (stop.id.startsWith('new-')) {
          const { data: inserted, error } = await supabase.from('stops')
            .insert({ name: stop.name, lat: stop.lat, lon: stop.lon, status: 'pending', contributor_id: user.id })
            .select().single();
          if (error) throw error;
          resolvedStops.push(inserted as Stop);
        } else {
          resolvedStops.push(stop);
        }
      }

      await supabase.from('trip_stops').insert(
        resolvedStops.map((s, idx) => ({ trip_id: (newTrip as any).id, stop_id: s.id, stop_sequence: idx + 1 }))
      );

      const fareAmount = editFare !== '' ? parseFloat(editFare) : null;
      if (fareAmount !== null) {
        await supabase.from('fares').insert({ trip_id: (newTrip as any).id, amount: fareAmount, currency: 'EGP' });
      }

      try {
        toast.loading('Generating route shape…', { id: 'osrm' });
        const { geojson, durationSeconds } = await getRouteShape(resolvedStops.map((s) => ({ lat: s.lat, lon: s.lon })));
        await supabase.from('trip_shapes').insert({ trip_id: (newTrip as any).id, geojson: geojson as any });
        await supabase.from('trip_durations').insert({ trip_id: (newTrip as any).id, duration_seconds: durationSeconds });
        toast.success('Submitted for review!', { id: 'osrm' });
      } catch {
        toast.warning('Submitted, but route shape could not be generated.', { id: 'osrm' });
      }

      onOpenChange(false);
    } catch (err) {
      console.error(err); toast.error('Failed to submit');
    } finally {
      setSaving(false);
    }
  };

  const availableStops = allStops.filter((s) => !editStops.some((es) => es.id === s.id));
  if (!open) return null;

  return createPortal(
    <div
      style={{ position: 'fixed', inset: 0, zIndex: 99999, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.6)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onOpenChange(false); }}
    >
      <div style={{ width: 'min(1100px, 95vw)', height: '90vh', display: 'flex', flexDirection: 'column', background: 'hsl(var(--background))', borderRadius: 12, overflow: 'hidden', boxShadow: '0 24px 80px rgba(0,0,0,0.5)' }}>
        <div className="flex items-center justify-between px-5 py-3 border-b border-border/60 flex-shrink-0">
          <div>
            <p className="text-sm font-semibold">Propose edits to &quot;{trip.name}&quot;</p>
            <p className="text-xs text-muted-foreground mt-0.5">Your changes create a new pending trip for review · original stays unchanged</p>
          </div>
          <div className="flex gap-2 items-center">
            <div className="flex items-center gap-2 mr-2">
              <label className="text-xs text-muted-foreground">Fare (EGP)</label>
              <Input type="number" value={editFare} onChange={(e) => setEditFare(e.target.value)} placeholder="e.g. 5" className="w-24 h-7 text-xs" />
            </div>
            <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button size="sm" onClick={handleSubmitForReview} disabled={saving} className="bg-blue-600 hover:bg-blue-700 text-white">
              {saving ? 'Submitting…' : '📤 Submit for Review'}
            </Button>
          </div>
        </div>

        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          <div style={{ flex: 1, position: 'relative' }}>
            {mapReady && (
              <MapView onClick={handleMapCoordClick}>
                <EditMapLayer routeStops={editStops} availableStops={availableStops} highlightedIdx={highlightedIdx} onStopClick={handleMapStopClick} onStopHover={setHighlightedIdx} />
              </MapView>
            )}
            {showSeqPrompt && (
              <div style={{ position: 'absolute', inset: 0, zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.4)' }}>
                <div className="bg-background border border-border rounded-xl p-5 shadow-2xl w-72">
                  <p className="font-semibold text-sm mb-1">{pendingMapStop ? `Add "${pendingMapStop.name || 'Stop'}"` : 'New stop'}</p>
                  <p className="text-xs text-muted-foreground mb-3">Insert at position (1 = first):</p>
                  <Input type="number" min={1} max={editStops.length + 1} value={seqValue} onChange={(e) => setSeqValue(e.target.value)} className="mb-3" autoFocus
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSequenceConfirm(Math.max(1, Math.min(editStops.length + 1, parseInt(seqValue) || 1)));
                      if (e.key === 'Escape') { setShowSeqPrompt(false); setPendingMapStop(null); setPendingCoord(null); }
                    }} />
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1" onClick={() => { setShowSeqPrompt(false); setPendingMapStop(null); setPendingCoord(null); }}>Cancel</Button>
                    <Button size="sm" className="flex-1" onClick={() => handleSequenceConfirm(Math.max(1, Math.min(editStops.length + 1, parseInt(seqValue) || 1)))}>Insert</Button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div style={{ width: 280, display: 'flex', flexDirection: 'column', borderLeft: '1px solid hsl(var(--border) / 0.6)', overflow: 'hidden' }}>
            <div className="px-3 py-2 border-b border-border/60 flex-shrink-0">
              <p className="text-xs font-medium text-muted-foreground">{editStops.length} stop{editStops.length !== 1 ? 's' : ''}</p>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
              {editStops.map((stop, idx) => {
                const isHighlighted = highlightedIdx === idx;
                const isNew = stop.id.startsWith('new-');
                return (
                  <div key={stop.id + idx} ref={(el) => { listRefs.current[idx] = el; }}
                    className={`flex items-center gap-2 px-2 py-1.5 rounded-lg cursor-pointer group transition-colors ${isHighlighted ? 'bg-amber-400/10 border border-amber-400/30' : 'hover:bg-muted border border-transparent'}`}
                    onClick={() => setHighlightedIdx(isHighlighted ? null : idx)}>
                    <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white ${isHighlighted ? 'bg-amber-400' : isNew ? 'bg-orange-500' : 'bg-blue-600'}`}>{idx + 1}</div>
                    <div className="flex-1 min-w-0" onClick={(e) => e.stopPropagation()}>
                      <Input value={stop.name ?? ''} onChange={(e) => updateStopName(idx, e.target.value)} placeholder={isNew ? 'Name this stop…' : 'Stop name'}
                        className={`h-7 text-xs border-0 bg-transparent px-0 focus-visible:ring-0 focus-visible:ring-offset-0 ${isNew ? 'placeholder:text-orange-400' : ''}`} />
                      <span className="text-[9px] text-muted-foreground font-mono leading-none">
                        {stop.lat.toFixed(5)}, {stop.lon.toFixed(5)}{isNew && <span className="ml-1 text-orange-400">new</span>}
                      </span>
                    </div>
                    <div className="flex items-center gap-0.5 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={(e) => { e.stopPropagation(); moveStop(idx, -1); }} disabled={idx === 0} className="w-5 h-5 flex items-center justify-center rounded hover:bg-muted disabled:opacity-25 text-[10px]">▲</button>
                      <button onClick={(e) => { e.stopPropagation(); moveStop(idx, 1); }} disabled={idx === editStops.length - 1} className="w-5 h-5 flex items-center justify-center rounded hover:bg-muted disabled:opacity-25 text-[10px]">▼</button>
                      <button onClick={(e) => { e.stopPropagation(); removeStop(idx); }} className="w-5 h-5 flex items-center justify-center rounded hover:bg-destructive/10 hover:text-destructive text-[10px]">✕</button>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="p-3 border-t border-border/60 flex-shrink-0 bg-muted/30">
              <p className="text-[10px] text-muted-foreground text-center leading-relaxed">Click green stops to add · Click map to create new stop</p>
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}

export function TripDetail({ trip, stops, fare, duration }: TripDetailProps) {
  const [showEditor, setShowEditor] = useState(false);

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-lg font-semibold">{trip.name}</h3>
          <Badge variant={trip.status === 'approved' || trip.status === 'existing' ? 'default' : trip.status === 'pending' ? 'secondary' : 'destructive'} className="mt-1">
            {trip.status}
          </Badge>
        </div>
        <Button size="sm" variant="outline" onClick={() => setShowEditor(true)} className="flex-shrink-0">
          ✏️ Suggest Edit
        </Button>
      </div>

      <Separator />

      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">Fare</span>
        <span className="font-medium">{fare && fare.amount !== null ? `${fare.amount} ${fare.currency || 'EGP'}` : 'Unknown'}</span>
      </div>

      {duration && duration.duration_seconds !== null && (
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Est. Travel Time</span>
          <span className="font-medium">{formatDuration(duration.duration_seconds)}</span>
        </div>
      )}

      <Separator />

      <div>
        <h4 className="text-sm font-medium text-muted-foreground mb-3">Stops ({stops.length})</h4>
        <div className="space-y-2">
          {stops.map((stop, idx) => (
            <div key={stop.id} className="flex items-center gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ background: stop.status === 'existing' ? '#9ca3af' : '#22c55e' }}>
                {idx + 1}
              </div>
              <span className="text-sm">{stop.name || 'Unnamed Stop'}</span>
            </div>
          ))}
        </div>
      </div>

      <StopEditor open={showEditor} onOpenChange={setShowEditor} trip={trip} initialStops={stops} fare={fare} />
    </div>
  );
}