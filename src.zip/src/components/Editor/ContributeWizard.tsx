'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase';
import { TripInfoStep } from './TripInfoStep';
import { StopPickerStep } from './StopPickerStep';
import { SubmittedStep } from './SubmittedStep';
import type { PickedStop } from '@/components/Map/StopPicker';
import { toast } from 'sonner';
import dynamic from 'next/dynamic';

const STEPS = ['Name', 'Stops', 'Preview', 'Done'];

const PreviewStep = dynamic(
  () => import('./PreviewStep').then((mod) => mod.PreviewStep),
  { ssr: false }
);

export function ContributeWizard() {
  const searchParams = useSearchParams();
  const prefill = searchParams.get('prefill') || '';

  const [step, setStep] = useState(0);
  const [tripName, setTripName] = useState(prefill);
  const [fareAmount, setFareAmount] = useState('');
  const [stops, setStops] = useState<PickedStop[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const supabase = createClient();

  const handleSubmit = async (
    shape: GeoJSON.LineString,
    durationSeconds: number
  ) => {
    setSubmitting(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        toast.error('You must be logged in to submit');
        return;
      }

      // 1. Insert trip
      const { data: trip, error: tripError } = await supabase
        .from('trips')
        .insert({
          name: tripName,
          status: 'pending' as const,
          contributor_id: user.id,
        } as any)
        .select()
        .single();

      if (tripError || !trip) throw tripError || new Error('Failed to create trip');

      // 2. Insert new stops
      const stopIds: string[] = [];
      for (const pickedStop of stops) {
        if (pickedStop.isExisting && pickedStop.id) {
          stopIds.push(pickedStop.id);
        } else {
          const { data: newStop, error: stopError } = await supabase
            .from('stops')
            .insert({
              name: pickedStop.name || null,
              lat: pickedStop.lat,
              lon: pickedStop.lon,
              status: 'pending' as const,
              contributor_id: user.id,
            } as any)
            .select()
            .single();

          if (stopError || !newStop) throw stopError || new Error('Failed to create stop');
          stopIds.push((newStop as any).id);
        }
      }

      // 3. Insert trip_stops (ordered)
      const tripId = (trip as any).id;
      const tripStopsInserts = stopIds.map((stopId, idx) => ({
        trip_id: tripId,
        stop_id: stopId,
        stop_sequence: idx,
      }));
      const { error: tsError } = await supabase
        .from('trip_stops')
        .insert(tripStopsInserts as any);
      if (tsError) throw tsError;

      // 4. Insert trip shape
      const { error: shapeError } = await supabase
        .from('trip_shapes')
        .insert({
          trip_id: tripId,
          geojson: shape as unknown as Record<string, unknown>,
        } as any);
      if (shapeError) throw shapeError;

      // 5. Insert fare (if provided)
      if (fareAmount && !isNaN(parseFloat(fareAmount))) {
        await supabase.from('fares').insert({
          trip_id: tripId,
          amount: parseFloat(fareAmount),
          currency: 'EGP',
        } as any);
      }

      // 6. Insert duration
      await supabase.from('trip_durations').insert({
        trip_id: tripId,
        duration_seconds: durationSeconds,
      } as any);

      toast.success('Contribution submitted successfully!');
      setStep(3);
    } catch (err) {
      console.error('Submit error:', err);
      toast.error('Failed to submit contribution. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Stepper */}
      {step < 3 && (
        <div className="px-4 py-3 border-b border-border/50 bg-background/95 backdrop-blur-sm">
          <div className="flex items-center justify-center gap-2 max-w-lg mx-auto">
            {STEPS.slice(0, 3).map((label, idx) => (
              <div key={label} className="flex items-center gap-2">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                    idx <= step
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground'
                  }`}
                >
                  {idx + 1}
                </div>
                <span
                  className={`text-sm hidden sm:inline ${
                    idx <= step
                      ? 'text-foreground font-medium'
                      : 'text-muted-foreground'
                  }`}
                >
                  {label}
                </span>
                {idx < 2 && (
                  <div
                    className={`w-8 h-0.5 ${
                      idx < step ? 'bg-primary' : 'bg-muted'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Step content */}
      <div className="flex-1 overflow-hidden">
        {step === 0 && (
          <div className="p-6">
            <TripInfoStep
              tripName={tripName}
              onTripNameChange={setTripName}
              fareAmount={fareAmount}
              onFareAmountChange={setFareAmount}
              onNext={() => setStep(1)}
            />
          </div>
        )}
        {step === 1 && (
          <StopPickerStep
            stops={stops}
            onStopsChange={setStops}
            onNext={() => setStep(2)}
            onBack={() => setStep(0)}
          />
        )}
        {step === 2 && (
          <PreviewStep
            stops={stops}
            onSubmit={handleSubmit}
            onBack={() => setStep(1)}
          />
        )}
        {step === 3 && <SubmittedStep />}
      </div>

      {/* Submitting overlay */}
      {submitting && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-background border border-border/50 rounded-xl p-8 shadow-xl flex flex-col items-center gap-4">
            <div className="w-10 h-10 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="font-medium">Submitting your contribution...</p>
          </div>
        </div>
      )}
    </div>
  );
}
