'use client';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface TripInfoStepProps {
  tripName: string;
  onTripNameChange: (name: string) => void;
  fareAmount: string;
  onFareAmountChange: (amount: string) => void;
  onNext: () => void;
}

export function TripInfoStep({
  tripName,
  onTripNameChange,
  fareAmount,
  onFareAmountChange,
  onNext,
}: TripInfoStepProps) {
  return (
    <div className="space-y-6 max-w-md mx-auto">
      <div>
        <h2 className="text-2xl font-bold">Name the Trip</h2>
        <p className="text-muted-foreground mt-1">
          Give this route a recognizable name
        </p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="trip-name">Trip Name *</Label>
          <Input
            id="trip-name"
            placeholder='e.g. "الدائري - سيدي بشر"'
            value={tripName}
            onChange={(e) => onTripNameChange(e.target.value)}
            className="text-base"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="fare">Fare Amount (optional)</Label>
          <div className="flex gap-2">
            <Input
              id="fare"
              type="number"
              step="0.5"
              min="0"
              placeholder="e.g. 5"
              value={fareAmount}
              onChange={(e) => onFareAmountChange(e.target.value)}
              className="flex-1"
            />
            <div className="flex items-center px-3 rounded-md border border-input bg-muted text-sm text-muted-foreground">
              EGP
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Leave blank if you don&apos;t know the fare
          </p>
        </div>
      </div>

      <Button
        size="lg"
        className="w-full"
        onClick={onNext}
        disabled={!tripName.trim()}
      >
        Next — Pick Stops →
      </Button>
    </div>
  );
}
