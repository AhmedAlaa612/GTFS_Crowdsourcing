'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { PendingQueue, type PendingQueueRef } from '@/components/Review/PendingQueue';
import { ReviewActions } from '@/components/Review/ReviewActions';
import { createClient } from '@/lib/supabase';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { formatDuration } from '@/lib/osrm';
import type { Trip, Stop, Fare, TripDuration, TripStop } from '@/lib/database.types';
import dynamic from 'next/dynamic';
import type { DiffMapRef } from '@/components/Review/DiffMap';

const DiffMap = dynamic(
  () => import('@/components/Review/DiffMap').then((mod) => mod.DiffMap),
  { ssr: false }
);

const supabase = createClient();

export default function ReviewPage() {
  const queueRef = useRef<PendingQueueRef>(null);
  const diffMapRef = useRef<DiffMapRef>(null);

  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [tripStops, setTripStops] = useState<Stop[]>([]);
  const [fare, setFare] = useState<Fare | null>(null);
  const [duration, setDuration] = useState<TripDuration | null>(null);
  // Increment this after every edit save to force DiffMap to fully remount,
  // clearing the stale polyline and stop markers from the previous version.
  const [mapKey, setMapKey] = useState(0);

  useEffect(() => {
    if (!selectedTrip) {
      setTripStops([]);
      setFare(null);
      setDuration(null);
      return;
    }

    const load = async () => {
      const { data: ts } = await supabase
        .from('trip_stops')
        .select('*')
        .eq('trip_id', selectedTrip.id)
        .order('stop_sequence');

      if (ts) {
        const tripStopsData = ts as TripStop[];
        const stopIds = tripStopsData.map((t) => t.stop_id);
        const { data: stopsData } = await supabase.from('stops').select('*').in('id', stopIds);
        if (stopsData) {
          const ordered = tripStopsData
            .map((tripStop) => (stopsData as Stop[]).find((s) => s.id === tripStop.stop_id))
            .filter((s): s is Stop => Boolean(s));
          setTripStops(ordered);
        }
      }

      const { data: fareData } = await supabase.from('fares').select('*').eq('trip_id', selectedTrip.id).single();
      setFare(fareData);

      const { data: durationData } = await supabase.from('trip_durations').select('*').eq('trip_id', selectedTrip.id).single();
      setDuration(durationData);
    };

    load();
  }, [selectedTrip]);

  const handleActionComplete = () => {
    setSelectedTrip(null);
    queueRef.current?.reload();
  };

  // Called by ReviewActions after a successful edit save (all DB writes done)
  const handleStopsChange = (stops: Stop[]) => {
    setTripStops(stops);
    // Bump mapKey to fully remount DiffMap — this clears the old polyline and
    // stop markers instead of trying to patch them in place, which avoids the
    // stale-path / missing-stops issue after edits.
    setMapKey((k) => k + 1);
  };

  return (
    <div className="h-screen flex flex-col">
      <header className="h-14 border-b border-border/50 bg-background/95 backdrop-blur-xl flex items-center justify-between px-4 z-30 relative flex-shrink-0">
        <div className="flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
              <span className="text-white font-bold text-sm">🚌</span>
            </div>
            <span className="font-bold text-lg hidden sm:inline">Alexandria Transit</span>
          </Link>
          <span className="text-muted-foreground text-sm">/</span>
          <span className="text-sm font-medium">Review</span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => window.open('/api/export/gtfs', '_blank')}>
            📦 Export GTFS
          </Button>
          <Link href="/" className="text-sm px-3 py-1.5 rounded-md hover:bg-accent transition-colors">
            ← Map
          </Link>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <div className="w-full sm:w-[320px] lg:w-[360px] border-r border-border/50 bg-background overflow-y-auto p-4 flex-shrink-0">
          <PendingQueue
            ref={queueRef}
            onSelectTrip={setSelectedTrip}
            selectedTripId={selectedTrip?.id || null}
          />
        </div>

        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 relative min-h-0">
            {/* ref lets ReviewActions trigger reload() only after all DB writes finish */}
            <DiffMap
              key={mapKey}
              ref={diffMapRef}
              trip={selectedTrip}
            />
          </div>

          {selectedTrip && (
            <div className="border-t border-border/50 bg-background/95 backdrop-blur-sm p-4 max-h-[320px] overflow-y-auto">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">{selectedTrip.name}</h3>
                    <p className="text-xs text-muted-foreground" suppressHydrationWarning>
                      Submitted{' '}
                      {new Date(selectedTrip.created_at).toLocaleDateString('en-US', {
                        month: 'short', day: 'numeric', year: 'numeric',
                        hour: '2-digit', minute: '2-digit',
                      })}
                    </p>
                  </div>
                  <Badge variant="secondary">pending</Badge>
                </div>

                <div className="flex gap-6 text-sm">
                  <div>
                    <span className="text-muted-foreground">Stops: </span>
                    <strong>{tripStops.length}</strong>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Fare: </span>
                    <strong>
                      {fare && fare.amount != null ? `${fare.amount} ${fare.currency || 'EGP'}` : 'Unknown'}
                    </strong>
                  </div>
                  {duration && duration.duration_seconds != null && (
                    <div>
                      <span className="text-muted-foreground">Est. Time: </span>
                      <strong>{formatDuration(duration.duration_seconds)}</strong>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap gap-1">
                  {tripStops.map((stop, idx) => (
                    <span key={stop.id} className="inline-flex items-center gap-1 text-xs bg-muted px-2 py-0.5 rounded-full">
                      <span className="font-bold">{idx + 1}.</span>
                      {stop.name || 'Unnamed'}
                    </span>
                  ))}
                </div>

                <Separator />

                <ReviewActions
                  trip={selectedTrip}
                  tripStops={tripStops}
                  fare={fare}
                  onActionComplete={handleActionComplete}
                  onStopsChange={handleStopsChange}
                  onFareChange={setFare}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}