"use client";

import { useState, useEffect, useCallback, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import type L from "leaflet";
import Link from "next/link";
import { MapView } from "@/components/Map/MapView";
import { SidebarDrawer } from "@/components/Sidebar/SidebarDrawer";
import { TripDetail } from "@/components/Sidebar/TripDetail";
import { NearbyTripsPanel } from "@/components/Sidebar/NearbyTripsPanel";
import { GapChecklist } from "@/components/Sidebar/GapChecklist";
import { RoutesPanel } from "@/components/Sidebar/RoutesPanel";
import { AuthButton } from "@/components/Auth/AuthButton";
import { createClient } from "@/lib/supabase";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type {
  Stop,
  Trip,
  TripShape,
  Fare,
  TripDuration,
  TripStop,
} from "@/lib/database.types";
import type { User } from "@supabase/supabase-js";
import { toast } from "sonner";
import dynamic from "next/dynamic";
const StopLayer = dynamic(
  () => import("@/components/Map/StopLayer").then((mod) => mod.StopLayer),
  { ssr: false }
);
const RouteLayer = dynamic(
  () => import("@/components/Map/RouteLayer").then((mod) => mod.RouteLayer),
  { ssr: false }
);
const supabase = createClient();

function PublicViewContent() {
  const searchParams = useSearchParams();
  const [map, setMap] = useState<L.Map | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<string>("viewer");

  // Data
  const [stops, setStops] = useState<Stop[]>([]);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [shapes, setShapes] = useState<TripShape[]>([]);
  const [fares, setFares] = useState<Fare[]>([]);
  const [durations, setDurations] = useState<TripDuration[]>([]);
  const [tripStopsData, setTripStopsData] = useState<TripStop[]>([]);

  // Sidebar state
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [selectedStop, setSelectedStop] = useState<Stop | null>(null);
  const [nearbyPoint, setNearbyPoint] = useState<{
    lat: number;
    lon: number;
  } | null>(null);
  const [sidebarTab, setSidebarTab] = useState<"trip" | "nearby" | "gap">(
    "trip",
  );

  // Handle toast from redirects
  useEffect(() => {
    const toastType = searchParams.get("toast");
    if (toastType === "login_required") {
      toast.error("Please log in to continue");
    } else if (toastType === "editor_required") {
      toast.error("You need editor access to contribute");
    } else if (toastType === "reviewer_required") {
      toast.error("You need reviewer access for this page");
    }
  }, [searchParams]);

  // Load and sync user
  useEffect(() => {
    // Check initial session
    supabase.auth.getUser().then((response: any) => {
      const user = response.data.user;
      if (user) {
        setUser(user);
        setUserRole("editor");
      }
    });

    // Listen for changes (login/logout)
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event: any, session: any) => {
      const currentUser = session?.user || null;
      setUser(currentUser);
      if (currentUser) {
        setUserRole("editor");
      } else {
        setUserRole("viewer");
      }
    });

    return () => subscription.unsubscribe();
  }, []); // supabase is a module-level constant, no need to re-run

  // Load map data
  useEffect(() => {
    const loadData = async () => {
      try {
        const [
          stopsRes,
          tripsRes,
          shapesRes,
          faresRes,
          durationsRes,
          tripStopsRes,
        ] = await Promise.all([
          supabase.from("stops").select("*"),
          supabase.from("trips").select("*").in("status", ["approved", "existing"]),
          supabase.from("trip_shapes").select("*"),
          supabase.from("fares").select("*"),
          supabase.from("trip_durations").select("*"),
          supabase.from("trip_stops").select("*").order("stop_sequence"),
        ]);

        if (stopsRes.error) throw stopsRes.error;

        if (stopsRes.data) setStops(stopsRes.data);
        if (tripsRes.data) setTrips(tripsRes.data);
        if (shapesRes.data) setShapes(shapesRes.data);
        if (faresRes.data) setFares(faresRes.data);
        if (durationsRes.data) setDurations(durationsRes.data);
        if (tripStopsRes.data) setTripStopsData(tripStopsRes.data);
      } catch (err) {
        console.error("Data load error:", err);
        toast.error(
          "Failed to load map data. Check your connection or Supabase settings.",
        );
      }
    };
    loadData();
  }, []); // supabase is a module-level constant

  const handleMapReady = useCallback((m: L.Map) => {
    setMap(m);
  }, []);

  const handleTripClick = useCallback((trip: Trip) => {
    setSelectedTrip(trip);
    setSelectedStop(null);
    setNearbyPoint(null);
    setSidebarTab("trip");
    setSidebarOpen(true);

    // Fly map to the selected route's shape or stops
    if (map) {
      import("leaflet").then((L) => {
        const shape = shapes.find((s) => s.trip_id === trip.id);
        const bounds = L.default.latLngBounds([]);
        if (shape?.geojson?.coordinates?.length) {
          shape.geojson.coordinates.forEach((pt: any) => bounds.extend([pt[1], pt[0]]));
        } else {
          const stopIds = tripStopsData
            .filter((ts) => ts.trip_id === trip.id)
            .map((ts) => ts.stop_id);
          stops
            .filter((s) => stopIds.includes(s.id))
            .forEach((s) => bounds.extend([s.lat, s.lon]));
        }
        if (bounds.isValid()) map.flyToBounds(bounds, { padding: [60, 60], duration: 0.8 });
      });
    }
  }, [map, shapes, stops, tripStopsData]);

  const handleStopClick = useCallback((stop: Stop) => {
    setSelectedStop(stop);
    setSelectedTrip(null);
    setNearbyPoint(null);
    setSidebarTab("gap");
    setSidebarOpen(true);
  }, []);

  const handleMapClick = useCallback((lngLat: { lng: number; lat: number }) => {
    setNearbyPoint({ lat: lngLat.lat, lon: lngLat.lng });
    setSelectedTrip(null);
    setSelectedStop(null);
    setSidebarTab("nearby");
    setSidebarOpen(true);
  }, []);

  // Get trip stops for selected trip
  const selectedTripStops = selectedTrip
    ? (tripStopsData
        .filter((ts) => ts.trip_id === selectedTrip.id)
        .sort((a, b) => a.stop_sequence - b.stop_sequence)
        .map((ts) => stops.find((s) => s.id === ts.stop_id))
        .filter(Boolean) as Stop[])
    : [];

  const selectedFare = selectedTrip
    ? fares.find((f) => f.trip_id === selectedTrip.id) || null
    : null;

  const selectedDuration = selectedTrip
    ? durations.find((d) => d.trip_id === selectedTrip.id) || null
    : null;

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <header className="h-14 border-b border-border/50 bg-background/95 backdrop-blur-xl flex items-center justify-between px-4 z-30 relative">
        <div className="flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2">
            <span className="font-bold text-lg hidden sm:inline">
              Alexandria GTFS Editor
            </span>
          </Link>
        </div>

        <nav className="flex items-center gap-2">
          {(userRole === "editor" || userRole === "reviewer") && (
            <Link
              href="/contribute"
              className="text-sm px-3 py-1.5 rounded-md hover:bg-accent transition-colors font-medium"
            >
              ✚ Contribute
            </Link>
          )}
          {userRole === "reviewer" && (
            <Link
              href="/review"
              className="text-sm px-3 py-1.5 rounded-md hover:bg-accent transition-colors font-medium"
            >
              📋 Review
            </Link>
          )}
          <AuthButton initialUser={user} />
        </nav>
      </header>

      {/* Map */}
      <div className="flex-1 relative">
        <MapView onMapReady={handleMapReady} onClick={handleMapClick}>
          {map && (
            <>
              {selectedTrip ? (
                // Isolated mode: show only the selected trip's shape + its stops
                <>
                  <RouteLayer
                    trips={[selectedTrip]}
                    shapes={shapes}
                    onTripClick={handleTripClick}
                  />
                  <StopLayer
                    stops={selectedTripStops}
                    onStopClick={handleStopClick}
                  />
                </>
              ) : (
                // Default mode: show all routes + approved stops
                <>
                  <RouteLayer
                    trips={trips}
                    shapes={shapes}
                    onTripClick={handleTripClick}
                  />
                  <StopLayer
                    stops={stops.filter(
                      (s) => s.status === "existing" || s.status === "approved",
                    )}
                    onStopClick={handleStopClick}
                  />
                </>
              )}
            </>
          )}
        </MapView>

        {/* Routes search panel */}
        <RoutesPanel
          trips={trips}
          fares={fares}
          durations={durations}
          selectedTripId={selectedTrip?.id ?? null}
          onSelectTrip={handleTripClick}
        />

        {/* Stats badge */}
        <div className="absolute bottom-6 left-4 bg-background/90 backdrop-blur-sm rounded-lg px-3 py-2 border border-border/50 shadow-lg z-20">
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span>
              <strong className="text-foreground">{trips.length}</strong> routes
            </span>
            <span>
              <strong className="text-foreground">{stops.length}</strong> stops
            </span>
          </div>
        </div>
      </div>

      {/* Sidebar */}
      <SidebarDrawer
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        title={
          sidebarTab === "trip"
            ? "Trip Details"
            : sidebarTab === "gap"
              ? "مواقف Check"
              : "Nearby Trips"
        }
      >
        <Tabs
          value={sidebarTab}
          onValueChange={(v) => setSidebarTab(v as typeof sidebarTab)}
        >
          <TabsList className="w-full">
            <TabsTrigger value="trip" className="flex-1">
              Trip
            </TabsTrigger>
            <TabsTrigger value="nearby" className="flex-1">
              Nearby
            </TabsTrigger>
            <TabsTrigger value="gap" className="flex-1">
              مواقف
            </TabsTrigger>
          </TabsList>

          <TabsContent value="trip" className="mt-4">
            {selectedTrip ? (
              <TripDetail
                trip={selectedTrip}
                stops={selectedTripStops}
                fare={selectedFare}
                duration={selectedDuration}
              />
            ) : (
              <p className="text-sm text-muted-foreground py-4">
                Click a route on the map to see details
              </p>
            )}
          </TabsContent>

          <TabsContent value="nearby" className="mt-4">
            {nearbyPoint ? (
              <NearbyTripsPanel
                lat={nearbyPoint.lat}
                lon={nearbyPoint.lon}
                isLoggedIn={!!user}
              />
            ) : (
              <p className="text-sm text-muted-foreground py-4">
                Click anywhere on the map to find nearby trips
              </p>
            )}
          </TabsContent>

          <TabsContent value="gap" className="mt-4">
            {selectedStop ? (
              <GapChecklist stop={selectedStop} />
            ) : (
              <p className="text-sm text-muted-foreground py-4">
                Click a stop on the map to check for gaps
              </p>
            )}
          </TabsContent>
        </Tabs>
      </SidebarDrawer>
    </div>
  );
}

export default function PublicViewPage() {
  return (
    <Suspense
      fallback={
        <div className="h-screen flex items-center justify-center">
          Loading...
        </div>
      }
    >
      <PublicViewContent />
    </Suspense>
  );
}