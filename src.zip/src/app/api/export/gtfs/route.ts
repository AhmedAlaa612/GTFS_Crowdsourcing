import { NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase-server';
import { buildGtfsZip } from '@/lib/gtfs-export';
import type { Trip, Stop, TripStop, TripShape, Fare } from '@/lib/database.types';

export async function GET() {
  try {
    const supabase = createServiceClient();

    // Fetch all approved data
    const tripsRes = await supabase.from('trips').select('*').eq('status', 'approved');
    const stopsRes = await supabase.from('stops').select('*').in('status', ['existing', 'approved']);
    const tripStopsRes = await supabase.from('trip_stops').select('*');
    const shapesRes = await supabase.from('trip_shapes').select('*');
    const faresRes = await supabase.from('fares').select('*');

    const trips = (tripsRes.data || []) as Trip[];
    const stops = (stopsRes.data || []) as Stop[];
    const allTripStops = (tripStopsRes.data || []) as TripStop[];
    const allShapes = (shapesRes.data || []) as TripShape[];
    const allFares = (faresRes.data || []) as Fare[];

    // Filter trip_stops and shapes to only approved trips
    const approvedTripIds = new Set(trips.map((t) => t.id));

    const filteredTripStops = allTripStops.filter((ts) =>
      approvedTripIds.has(ts.trip_id)
    );
    const filteredShapes = allShapes.filter((s) =>
      approvedTripIds.has(s.trip_id)
    );
    const filteredFares = allFares.filter((f) =>
      approvedTripIds.has(f.trip_id)
    );

    const zip = await buildGtfsZip({
      trips,
      stops,
      tripStops: filteredTripStops,
      tripShapes: filteredShapes,
      fares: filteredFares,
    });

    return new NextResponse(zip as unknown as BodyInit, {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename="gtfs_export.zip"',
      },
    });
  } catch (error) {
    console.error('GTFS export error:', error);
    return NextResponse.json(
      { error: 'Failed to generate GTFS export' },
      { status: 500 }
    );
  }
}
