'use client';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export type InputMethod = 'stops' | 'file';

interface TripInfoStepProps {
  tripName: string;
  onTripNameChange: (name: string) => void;
  fareAmount: string;
  onFareAmountChange: (amount: string) => void;
  comment: string;
  onCommentChange: (comment: string) => void;
  inputMethod: InputMethod;
  onInputMethodChange: (method: InputMethod) => void;
  onNext: () => void;
}

export function TripInfoStep({
  tripName,
  onTripNameChange,
  fareAmount,
  onFareAmountChange,
  comment,
  onCommentChange,
  inputMethod,
  onInputMethodChange,
  onNext,
}: TripInfoStepProps) {
  return (
    <div className="space-y-6 max-w-md mx-auto">
      <div>
        <h2 className="text-2xl font-bold">Name the Trip</h2>
        <p className="text-muted-foreground mt-1">
          Give this route a recognizable name
        </p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="trip-name">Trip Name *</Label>
          <Input
            id="trip-name"
            placeholder='e.g. "الدائري - سيدي بشر"'
            value={tripName}
            onChange={(e) => onTripNameChange(e.target.value)}
            className="text-base"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="fare">Fare Amount (optional)</Label>
          <div className="flex gap-2">
            <Input
              id="fare"
              type="number"
              step="0.5"
              min="0"
              placeholder="e.g. 5"
              value={fareAmount}
              onChange={(e) => onFareAmountChange(e.target.value)}
              className="flex-1"
            />
            <div className="flex items-center px-3 rounded-md border border-input bg-muted text-sm text-muted-foreground">
              EGP
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Leave blank if you don&apos;t know the fare
          </p>
        </div>

        {/* How to define the route */}
        <div className="space-y-2">
          <Label>How will you define the route?</Label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => onInputMethodChange('stops')}
              className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 text-sm font-medium transition-all ${
                inputMethod === 'stops'
                  ? 'border-primary bg-primary/5 text-primary'
                  : 'border-border hover:border-primary/40 text-muted-foreground hover:text-foreground'
              }`}
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              <span>Pick stops on map</span>
            </button>

            <button
              type="button"
              onClick={() => onInputMethodChange('file')}
              className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 text-sm font-medium transition-all ${
                inputMethod === 'file'
                  ? 'border-primary bg-primary/5 text-primary'
                  : 'border-border hover:border-primary/40 text-muted-foreground hover:text-foreground'
              }`}
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
              </svg>
              <span>Upload GPX / GeoJSON</span>
            </button>
          </div>
          <p className="text-xs text-muted-foreground">
            {inputMethod === 'file'
              ? 'Upload a file — a reviewer will refine the stops after.'
              : 'Click stops on the map to build the sequence manually.'}
          </p>
        </div>

        {/* Comment — always visible */}
        <div className="space-y-2">
          <Label htmlFor="comment">Comment (optional)</Label>
          <Textarea
            id="comment"
            placeholder="Any notes for reviewers — e.g. frequency, operating hours, variant details…"
            value={comment}
            onChange={(e) => onCommentChange(e.target.value)}
            rows={3}
            className="resize-none text-sm"
          />
        </div>
      </div>

      <Button
        size="lg"
        className="w-full"
        onClick={onNext}
        disabled={!tripName.trim()}
      >
        {inputMethod === 'file' ? 'Next — Upload File →' : 'Next — Pick Stops →'}
      </Button>
    </div>
  );
}