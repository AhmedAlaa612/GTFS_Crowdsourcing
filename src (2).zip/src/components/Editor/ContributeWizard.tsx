'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase';
import { TripInfoStep, type InputMethod } from './TripInfoStep';
import { StopPickerStep } from './StopPickerStep';
import { SubmittedStep } from './SubmittedStep';
import type { PickedStop } from '@/components/Map/StopPicker';
import { toast } from 'sonner';
import dynamic from 'next/dynamic';

const PreviewStep = dynamic(
  () => import('./PreviewStep').then((mod) => mod.PreviewStep),
  { ssr: false }
);

const GpxUploadStep = dynamic(
  () => import('./GpxUploadStep.tsx').then((mod) => mod.GpxUploadStep),
  { ssr: false }
);

// Step indices depend on the chosen method:
//
//  Option A (stops):  0=Info → 1=Stops → 2=Preview → 3=Done
//  Option B (file):   0=Info → 1=Upload → 2=Preview → 3=Done
//
// We reuse the same step numbers; the middle step just renders differently.

const STEPS_A = ['Name', 'Stops', 'Preview', 'Done'];
const STEPS_B = ['Name', 'Upload', 'Preview', 'Done'];

export function ContributeWizard() {
  const searchParams = useSearchParams();
  const prefill = searchParams.get('prefill') || '';

  const [step, setStep] = useState(0);

  // Shared state
  const [tripName, setTripName] = useState(prefill);
  const [fareAmount, setFareAmount] = useState('');
  const [comment, setComment] = useState('');
  const [inputMethod, setInputMethod] = useState<InputMethod>('stops');
  const [submitting, setSubmitting] = useState(false);

  // Option A state
  const [stops, setStops] = useState<PickedStop[]>([]);

  // Option B state
  const [importedShape, setImportedShape] = useState<GeoJSON.LineString | undefined>();
  const [importedStops, setImportedStops] = useState<PickedStop[]>([]);

  const supabase = createClient();

  const STEPS = inputMethod === 'file' ? STEPS_B : STEPS_A;

  // Resolved stops to use in PreviewStep
  const activeStops = inputMethod === 'file' ? importedStops : stops;

  const handleShapeReady = (
    shape: GeoJSON.LineString,
    rawStops: { lat: number; lon: number; name?: string }[]
  ) => {
    setImportedShape(shape);
    setImportedStops(
      rawStops.map((s) => ({ lat: s.lat, lon: s.lon, name: s.name, isExisting: false }))
    );
    setStep(2);
  };

  const handleSubmit = async (
    shape: GeoJSON.LineString,
    durationSeconds: number
  ) => {
    setSubmitting(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        toast.error('You must be logged in to submit');
        return;
      }

      // 1. Insert trip (include review_note as the contributor comment)
      const { data: trip, error: tripError } = await supabase
        .from('trips')
        .insert({
          name: tripName,
          status: 'pending' as const,
          contributor_id: user.id,
          // Store contributor comment in review_note until reviewer overwrites it
          ...(comment.trim() ? { review_note: comment.trim() } : {}),
        } as any)
        .select()
        .single();

      if (tripError || !trip) throw tripError || new Error('Failed to create trip');

      const tripId = (trip as any).id;

      // 2. Insert stops
      const stopsToInsert = activeStops;
      const stopIds: string[] = [];

      for (const pickedStop of stopsToInsert) {
        if (pickedStop.isExisting && pickedStop.id) {
          stopIds.push(pickedStop.id);
        } else {
          const { data: newStop, error: stopError } = await supabase
            .from('stops')
            .insert({
              name: pickedStop.name || null,
              lat: pickedStop.lat,
              lon: pickedStop.lon,
              status: 'pending' as const,
              contributor_id: user.id,
            } as any)
            .select()
            .single();

          if (stopError || !newStop) throw stopError || new Error('Failed to create stop');
          stopIds.push((newStop as any).id);
        }
      }

      // 3. Insert trip_stops (ordered)
      if (stopIds.length > 0) {
        const tripStopsInserts = stopIds.map((stopId, idx) => ({
          trip_id: tripId,
          stop_id: stopId,
          stop_sequence: idx,
        }));
        const { error: tsError } = await supabase
          .from('trip_stops')
          .insert(tripStopsInserts as any);
        if (tsError) throw tsError;
      }

      // 4. Insert trip shape
      const { error: shapeError } = await supabase
        .from('trip_shapes')
        .insert({
          trip_id: tripId,
          geojson: shape as unknown as Record<string, unknown>,
        } as any);
      if (shapeError) throw shapeError;

      // 5. Insert fare (if provided)
      if (fareAmount && !isNaN(parseFloat(fareAmount))) {
        await supabase.from('fares').insert({
          trip_id: tripId,
          amount: parseFloat(fareAmount),
          currency: 'EGP',
        } as any);
      }

      // 6. Insert duration (0 for file-imported routes — reviewer will update)
      await supabase.from('trip_durations').insert({
        trip_id: tripId,
        duration_seconds: durationSeconds,
      } as any);

      toast.success('Contribution submitted successfully!');
      setStep(3);
    } catch (err) {
      console.error('Submit error:', err);
      toast.error('Failed to submit contribution. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Stepper */}
      {step < 3 && (
        <div className="px-4 py-3 border-b border-border/50 bg-background/95 backdrop-blur-sm">
          <div className="flex items-center justify-center gap-2 max-w-lg mx-auto">
            {STEPS.slice(0, 3).map((label, idx) => (
              <div key={label} className="flex items-center gap-2">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                    idx <= step
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground'
                  }`}
                >
                  {idx + 1}
                </div>
                <span
                  className={`text-sm hidden sm:inline ${
                    idx <= step
                      ? 'text-foreground font-medium'
                      : 'text-muted-foreground'
                  }`}
                >
                  {label}
                </span>
                {idx < 2 && (
                  <div
                    className={`w-8 h-0.5 ${
                      idx < step ? 'bg-primary' : 'bg-muted'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Step content */}
      <div className="flex-1 overflow-hidden">
        {step === 0 && (
          <div className="p-6 overflow-y-auto h-full">
            <TripInfoStep
              tripName={tripName}
              onTripNameChange={setTripName}
              fareAmount={fareAmount}
              onFareAmountChange={setFareAmount}
              comment={comment}
              onCommentChange={setComment}
              inputMethod={inputMethod}
              onInputMethodChange={setInputMethod}
              onNext={() => setStep(1)}
            />
          </div>
        )}

        {step === 1 && inputMethod === 'stops' && (
          <StopPickerStep
            stops={stops}
            onStopsChange={setStops}
            onNext={() => setStep(2)}
            onBack={() => setStep(0)}
          />
        )}

        {step === 1 && inputMethod === 'file' && (
          <div className="p-6 overflow-y-auto h-full">
            <GpxUploadStep
              onShapeReady={handleShapeReady}
              onBack={() => setStep(0)}
            />
          </div>
        )}

        {step === 2 && (
          <div className="p-6 overflow-y-auto h-full">
            <PreviewStep
              stops={activeStops}
              importedShape={inputMethod === 'file' ? importedShape : undefined}
              onSubmit={handleSubmit}
              onBack={() => setStep(1)}
            />
          </div>
        )}

        {step === 3 && <SubmittedStep />}
      </div>

      {/* Submitting overlay */}
      {submitting && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-background border border-border/50 rounded-xl p-8 shadow-xl flex flex-col items-center gap-4">
            <div className="w-10 h-10 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="font-medium">Submitting your contribution...</p>
          </div>
        </div>
      )}
    </div>
  );
}